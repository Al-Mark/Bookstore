# ShoppingCartApi

All URIs are relative to *https://virtserver.swaggerhub.com/Al-Mark/API_for_integration_project_Publishing_house/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shoppingCart**](ShoppingCartApi.md#shoppingCart) | **POST** /shoppingcart | Shopping cart


<a name="shoppingCart"></a>
# **shoppingCart**
> List&lt;Shoppingcart&gt; shoppingCart(shoppingCart)

Shopping cart

This is a customer&#39;s shopping cart

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShoppingCartApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

ShoppingCartApi apiInstance = new ShoppingCartApi();
Shoppingcart shoppingCart = new Shoppingcart(); // Shoppingcart | Customer's shopping cart
try {
    List<Shoppingcart> result = apiInstance.shoppingCart(shoppingCart);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShoppingCartApi#shoppingCart");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shoppingCart** | [**Shoppingcart**](Shoppingcart.md)| Customer&#39;s shopping cart |

### Return type

[**List&lt;Shoppingcart&gt;**](Shoppingcart.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

