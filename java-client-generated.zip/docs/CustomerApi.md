# CustomerApi

All URIs are relative to *https://virtserver.swaggerhub.com/Al-Mark/API_for_integration_project_Publishing_house/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createCustomer**](CustomerApi.md#createCustomer) | **POST** /customer | Create customer
[**deleteCustomer**](CustomerApi.md#deleteCustomer) | **DELETE** /customer/{customername} | Delete customer
[**getCustomerByName**](CustomerApi.md#getCustomerByName) | **GET** /customer/{customername} | Get customer by customer name
[**loginCustomer**](CustomerApi.md#loginCustomer) | **GET** /customer/login | Logs customer into the system
[**logoutCustomer**](CustomerApi.md#logoutCustomer) | **GET** /customer/logout | Logs out current logged in customer session
[**updateCustomer**](CustomerApi.md#updateCustomer) | **PUT** /customer/{customername} | Updated customer


<a name="createCustomer"></a>
# **createCustomer**
> createCustomer(body)

Create customer

This can only be done by the logged in customer.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
Customer body = new Customer(); // Customer | Created customer object
try {
    apiInstance.createCustomer(body);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#createCustomer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Customer**](Customer.md)| Created customer object |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="deleteCustomer"></a>
# **deleteCustomer**
> deleteCustomer(customername)

Delete customer

This can only be done by the logged in customer.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
String customername = "customername_example"; // String | The name that needs to be deleted
try {
    apiInstance.deleteCustomer(customername);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#deleteCustomer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customername** | **String**| The name that needs to be deleted |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getCustomerByName"></a>
# **getCustomerByName**
> Customer getCustomerByName(customername)

Get customer by customer name

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
String customername = "customername_example"; // String | The name that needs to be fetched. Use customer1 for testing.
try {
    Customer result = apiInstance.getCustomerByName(customername);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#getCustomerByName");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customername** | **String**| The name that needs to be fetched. Use customer1 for testing. |

### Return type

[**Customer**](Customer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="loginCustomer"></a>
# **loginCustomer**
> String loginCustomer(customername, password)

Logs customer into the system

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
String customername = "customername_example"; // String | The customer name for login
String password = "password_example"; // String | The password for login in clear text
try {
    String result = apiInstance.loginCustomer(customername, password);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#loginCustomer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customername** | **String**| The customer name for login |
 **password** | **String**| The password for login in clear text |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="logoutCustomer"></a>
# **logoutCustomer**
> logoutCustomer()

Logs out current logged in customer session

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
try {
    apiInstance.logoutCustomer();
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#logoutCustomer");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateCustomer"></a>
# **updateCustomer**
> updateCustomer(customername, body)

Updated customer

This can only be done by the logged in customer.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
String customername = "customername_example"; // String | name that need to be updated
Customer body = new Customer(); // Customer | Updated customer object
try {
    apiInstance.updateCustomer(customername, body);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#updateCustomer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customername** | **String**| name that need to be updated |
 **body** | [**Customer**](Customer.md)| Updated customer object |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

