# CatalogApi

All URIs are relative to *https://virtserver.swaggerhub.com/Al-Mark/API_for_integration_project_Publishing_house/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addBook**](CatalogApi.md#addBook) | **POST** /book | Add a new book to the catalog
[**getBookByName**](CatalogApi.md#getBookByName) | **GET** /book/{bookName} | Find book by Name
[**getCatalog**](CatalogApi.md#getCatalog) | **GET** /catalog | get catalog
[**getNomenclature**](CatalogApi.md#getNomenclature) | **GET** /nomenclature | get nomenclature
[**updateBook**](CatalogApi.md#updateBook) | **PUT** /book | update an existing book


<a name="addBook"></a>
# **addBook**
> addBook(body)

Add a new book to the catalog

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CatalogApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: bookstore_auth
OAuth bookstore_auth = (OAuth) defaultClient.getAuthentication("bookstore_auth");
bookstore_auth.setAccessToken("YOUR ACCESS TOKEN");

CatalogApi apiInstance = new CatalogApi();
Book body = new Book(); // Book | Book object that needs to be added to the catalog
try {
    apiInstance.addBook(body);
} catch (ApiException e) {
    System.err.println("Exception when calling CatalogApi#addBook");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Book**](Book.md)| Book object that needs to be added to the catalog |

### Return type

null (empty response body)

### Authorization

[bookstore_auth](../README.md#bookstore_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getBookByName"></a>
# **getBookByName**
> Book getBookByName(bookName)

Find book by Name

Returns a single book

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CatalogApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: bookstore_auth
OAuth bookstore_auth = (OAuth) defaultClient.getAuthentication("bookstore_auth");
bookstore_auth.setAccessToken("YOUR ACCESS TOKEN");

CatalogApi apiInstance = new CatalogApi();
Long bookName = 789L; // Long | Name of book to return
try {
    Book result = apiInstance.getBookByName(bookName);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CatalogApi#getBookByName");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookName** | **Long**| Name of book to return |

### Return type

[**Book**](Book.md)

### Authorization

[bookstore_auth](../README.md#bookstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getCatalog"></a>
# **getCatalog**
> List&lt;Book&gt; getCatalog(author)

get catalog

Get list of products

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CatalogApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

CatalogApi apiInstance = new CatalogApi();
String author = "author_example"; // String | Author for filter
try {
    List<Book> result = apiInstance.getCatalog(author);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CatalogApi#getCatalog");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **author** | **String**| Author for filter | [optional]

### Return type

[**List&lt;Book&gt;**](Book.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getNomenclature"></a>
# **getNomenclature**
> List&lt;Book&gt; getNomenclature(item)

get nomenclature

Get nomenclature from 1S

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CatalogApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

CatalogApi apiInstance = new CatalogApi();
Book item = new Book(); // Book | New item
try {
    List<Book> result = apiInstance.getNomenclature(item);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CatalogApi#getNomenclature");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item** | [**Book**](Book.md)| New item |

### Return type

[**List&lt;Book&gt;**](Book.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateBook"></a>
# **updateBook**
> List&lt;Book&gt; updateBook(body)

update an existing book

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CatalogApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: bookstore_auth
OAuth bookstore_auth = (OAuth) defaultClient.getAuthentication("bookstore_auth");
bookstore_auth.setAccessToken("YOUR ACCESS TOKEN");

CatalogApi apiInstance = new CatalogApi();
Book body = new Book(); // Book | Book object that needs to be added to the store
try {
    List<Book> result = apiInstance.updateBook(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CatalogApi#updateBook");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Book**](Book.md)| Book object that needs to be added to the store |

### Return type

[**List&lt;Book&gt;**](Book.md)

### Authorization

[bookstore_auth](../README.md#bookstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

