
# Book

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isbn** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**author** | **String** |  |  [optional]
**price** | **Float** |  |  [optional]
**prodType** | **String** |  |  [optional]
**issueDate** | **String** |  |  [optional]
**pagesAmount** | **Integer** |  |  [optional]
**description** | **String** |  |  [optional]



