
# Customer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fullname** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
**email** | **String** |  |  [optional]
**phone** | **Integer** |  |  [optional]
**clientType** | **Boolean** |  |  [optional]



