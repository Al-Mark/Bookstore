
# Shoppingcart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderLineID** | **String** |  |  [optional]
**customerID** | **String** |  |  [optional]
**discount** | **Integer** |  |  [optional]
**subtotal** | **Integer** |  |  [optional]
**paymentOption** | **String** |  |  [optional]
**createDate** | **String** |  |  [optional]
**paymentDate** | **String** |  |  [optional]



